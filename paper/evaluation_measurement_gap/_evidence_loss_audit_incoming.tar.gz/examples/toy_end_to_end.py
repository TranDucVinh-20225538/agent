#!/usr/bin/env python3
"""A runnable, fully synthetic walk through the whole pipeline: discard ->
lock+sample -> two-stage sheets -> (fake) human labels -> chain summary.

No network calls, no real evaluator, no real annotators -- this exists so
a new user can see the shape of the whole thing end to end in a few
seconds, before wiring up their own adapter and real annotation. Run with:

    PYTHONPATH=. python3 examples/toy_end_to_end.py
"""
from __future__ import annotations

import random

from evidence_loss_audit.core.chain import ItemJudgement, summarize
from evidence_loss_audit.core.discard import discard_indices
from evidence_loss_audit.core.irr import fleiss_kappa, majority_label
from evidence_loss_audit.core.lock import Episode, SampleRule, draw_sample, render_lock_markdown
from evidence_loss_audit.core.protocol import DecisiveTarget, build_stage1_sheet, build_stage2_sheet

K = 3  # toy top-K cap


def fake_episode(key: str, n_items: int, n_criteria: int, seed: int) -> Episode:
    """Pretend to run a rubric x top-K filter: each criterion keeps a
    random K-sized subset of items; discard = union complement."""
    rng = random.Random(seed)
    keep_lists = {c: rng.sample(range(n_items), min(K, n_items)) for c in range(n_criteria)}
    discard = discard_indices(n_items, keep_lists)
    return Episode(key=key, n_items=n_items, discard_indices=tuple(discard))


def main() -> None:
    # 1. Build a toy population and freeze the sampling rule BEFORE looking at it.
    population = [fake_episode(f"task-{i:02d}", n_items=8 + i, n_criteria=3, seed=i) for i in range(12)]
    rule = SampleRule(seed=2026, census_cutoff=40, n_controls=3, pilot_size=2)
    print(render_lock_markdown(
        rule,
        title="TOY example",
        universe_note="12 synthetic episodes, 8-19 items each, K=3.",
        estimand_note="u_irr is the only estimand a real writeup may call 'evidence loss'.",
    ))

    # 2. Draw the sample (pure function of population + rule).
    draw = draw_sample(population, rule, opportunity=lambda e: e.n_items > K)
    print(f"event={len(draw.event)} control={len(draw.control)} stage1_items={len(draw.stage1_items)}")

    # 3. Build the blind Stage-1 sheet.
    sheet1, key1 = build_stage1_sheet(draw.stage1_items, seed=rule.seed)

    # 4. Fake three annotators labeling Stage 1 (in reality: real humans, real UI).
    rng = random.Random(0)
    labels = {name: {} for name in ("r1", "r2", "r3")}
    for item, truth in zip(sheet1, key1):
        # toy oracle: discarded items are "usually" decisive, kept items "usually" not --
        # annotators agree with the toy oracle most of the time, with noise.
        base = "DECISIVE" if truth.in_discard else "NOT_DECISIVE"
        for name in labels:
            labels[name][item.item_id] = base if rng.random() > 0.15 else rng.choice(
                ["DECISIVE", "NOT_DECISIVE", "UNCLEAR"]
            )

    rows = [[labels[r][it.item_id] for r in ("r1", "r2", "r3")] for it in sheet1]
    kappa = fleiss_kappa(rows, ["DECISIVE", "NOT_DECISIVE", "UNCLEAR"])
    print(f"stage-1 Fleiss kappa (toy, noisy oracle): {kappa:.3f}")

    majorities = {
        it.item_id: majority_label([labels[r][it.item_id] for r in ("r1", "r2", "r3")], hold="UNCLEAR")
        for it in sheet1
    }

    # 5. Build Stage-2 targets: every Stage-1-majority-DECISIVE item.
    episodes_by_key = {e.key: e for e in draw.event}
    targets = [
        DecisiveTarget(k.episode_key, k.item_index, in_discard=k.in_discard)
        for item, k in zip(sheet1, key1)
        if majorities[item.item_id] == "DECISIVE" and k.episode_key in episodes_by_key
    ]
    sheet2 = build_stage2_sheet(targets, episodes_by_key, seed=rule.seed)
    print(f"stage-2 items: {len(sheet2)} ({sum(1 for r in sheet2 if r.kind == 'discard_vs_keep')} discard, "
          f"{sum(1 for r in sheet2 if r.kind == 'keep_foil')} foil)")

    # 6. Fake Stage-2 labels: gallery items "usually" DO carry equivalent evidence when large.
    stage2_labels = {}
    for row in sheet2:
        equivalent = len(row.gallery_indices) >= 3 and rng.random() > 0.3
        stage2_labels[row.item_id] = equivalent

    # 7. Fold everything into ItemJudgements and summarize.
    judgements = []
    for item, k in zip(sheet1, key1):
        maj = majorities[item.item_id]
        decisive = None if maj is None else (maj == "DECISIVE")
        s2 = None
        for row in sheet2:
            if row.episode_key == k.episode_key and row.target_index == k.item_index:
                s2 = stage2_labels[row.item_id]
        judgements.append(ItemJudgement(item.item_id, discarded=k.in_discard, stage1_decisive=decisive, stage2_equivalent=s2))

    n_opportunity = sum(1 for e in population if e.n_items > K)
    n_discard_total = sum(e.n_discard for e in population)
    summary = summarize(judgements, n_opportunity=n_opportunity, n_discard_total=n_discard_total)
    print(f"n_opportunity={summary.n_opportunity} n_discard_total={summary.n_discard_total}")
    print(f"u_iso={summary.u_iso} u_red={summary.u_red} u_irr={summary.u_irr}  <- only u_irr is a loss claim")


if __name__ == "__main__":
    main()
