# evidence-loss-audit

Audit any evaluator that **collects evidence and then filters some of it
out before reaching a verdict** — for whether that filtering step
discarded evidence a human would call decisive, and whether that evidence
survived anywhere else in what the filter kept.

This is not specific to any one evaluator, benchmark, or modality. It
applies to anything shaped like: *observe → collect candidate evidence →
keep only some of it (top-K, a threshold, a scope window, a comparison
rule) → decide*. A rubric-and-screenshots judge for computer-use agents is
one instance (an adapter for it is included); a text-answer extractor that
accumulates candidate matches and then aggregates them is another; so is
any retrieval system that reranks-and-truncates before an LLM reads the
result.

## What this tool does **not** do

**This package does not, on its own, conclude that evidence was lost.**
It locates *candidates* — observations a mechanical filter discarded — and
gives you a pre-registered, blinded protocol for getting a human (or
whatever independent judge you trust) to confirm or refute each candidate.
The only thing this package computes for you mechanically is the *discard
set*: which observations survived none of the filter's keep-lists. Whether
a discarded observation actually mattered, and whether its evidence
survived anywhere else, are judgments the protocol asks a blinded human
for — this package structures that ask, tracks it, and refuses to let the
weaker, earlier links in the chain (see below) be reported as if they were
the final one.

## The four-link chain

```
opportunity  →  discard  →  decisive-in-isolation  →  irrecoverable
```

| Link | What it means | Who/what decides it |
|---|---|---|
| **opportunity** | The filter *could* have discarded something here (e.g. more observations than its cap K) | mechanical, population-level |
| **discard** | This specific observation was kept by none of the filter's keep-lists | mechanical (`core.discard`) |
| **decisive-in-isolation** | A human, shown *only this one observation* and blind to keep/discard status, says it alone would be necessary to reach the right verdict | Stage 1 human label |
| **irrecoverable** | Decisive-in-isolation, **and** a human shown a blinded gallery of what the filter *did* keep says none of it carries equivalent evidence | Stage 2 human label |

Only **irrecoverable** licenses an "evidence was collected and then lost"
claim. A decisive-but-discarded observation whose evidence survives
elsewhere in what was kept is **redundant** loss — real, but not that
claim — and this package reports it as a separate rate, never folded into
the headline number. Skipping straight from "opportunity" or "discard" to
a loss claim is the most common way this kind of audit overclaims; the
whole point of `core.chain` is to make that skip structurally visible
(every intermediate count is in `ChainSummary`) rather than silently easy.

## Why two stages, and why foils

Stage 1 asks "is this decisive, shown alone?" — cheap, but it cannot tell
you whether the *filter's own kept set* still contains the same evidence
somewhere else, which is the actual question a "was evidence lost"
headline needs answered. Stage 2 asks that directly, but only for items
Stage 1 already called decisive, and only by showing a blinded gallery —
never labeled "this is what got kept" or "this is what got discarded".

Every Stage-1-decisive observation that was *kept* also gets a Stage-2
gallery (drawn from the *other* kept observations, excluding itself) —
these **foils** exist so annotators cannot learn "if I'm shown a gallery
at all, this one must have been discarded" and start answering on that
inference instead of on the actual images/text in front of them. Building
a Stage-2 sheet without foils was a real blinding leak caught during
review of the project this package was extracted from — keep them.

## Install

```bash
pip install -e .          # core only, zero dependencies
pip install -e ".[uv-adapter]"   # + Pillow, if you use the Universal Verifier adapter's image handling
pip install -e ".[dev]"    # + pytest
```

## Quick start

```python
from evidence_loss_audit.core.discard import discard_indices
from evidence_loss_audit.core.lock import Episode, SampleRule, draw_sample, render_lock_markdown
from evidence_loss_audit.core.protocol import build_stage1_sheet, build_stage2_sheet, DecisiveTarget
from evidence_loss_audit.core.irr import fleiss_kappa, majority_label
from evidence_loss_audit.core.chain import ItemJudgement, summarize

# 1. Compute what your filter discarded, per episode (see adapters/ for a
#    worked example against a rubric x top-K screenshot filter).
discard = discard_indices(n_observations=19, keep_index_lists=my_per_criterion_keep_lists)

# 2. Freeze a sampling rule and render it to a lock document BEFORE
#    looking at your full population's discard rates.
rule = SampleRule(seed=20260913, census_cutoff=40, n_controls=20, pilot_size=6)
print(render_lock_markdown(rule, title="My evaluator", universe_note="..."))

# 3. Draw the sample once your population is loaded (pure, deterministic).
draw = draw_sample(my_episodes, rule, opportunity=lambda e: e.n_items > K)

# 4. Build blinded sheets, hand them to your annotators, collect labels,
#    fold the labels back into ItemJudgements, and summarize.
sheet1, key1 = build_stage1_sheet(draw.stage1_items, seed=rule.seed)
# ... collect >=2 independent labels per sheet1 item ...
kappa = fleiss_kappa(rows_of_labels, ["DECISIVE", "NOT_DECISIVE", "UNCLEAR"])
# ... majority_label() per item, build Stage-2 targets for majority-DECISIVE items ...
sheet2 = build_stage2_sheet(targets, episodes_by_key, seed=rule.seed)
# ... collect Stage-2 labels, fold into ItemJudgement(stage2_equivalent=...) ...
summary = summarize(judgements, n_opportunity=..., n_discard_total=...)
print(summary.u_irr)  # the only rate you may report as an evidence-loss claim
```

See `examples/toy_end_to_end.py` for a complete, runnable (synthetic,
no network calls) walk through every step above.

## Layout

```
evidence_loss_audit/
  core/            evaluator-agnostic. No knowledge of screenshots, rubrics,
                   text extraction, or any specific filter's internals.
    discard.py     union-of-keep-lists discard-set computation
    chain.py       the four-link chain: ItemJudgement, LossClass, classify(), summarize()
    lock.py        Episode/SampleRule/draw_sample() + lock-document rendering
    protocol.py    two-stage blinded sheet builders (Stage 1 isolation, Stage 2 gallery+foils)
    irr.py         Cohen's kappa, Fleiss' kappa, majority vote
  adapters/        evaluator-specific wiring. Add a new module here per evaluator.
    universal_verifier.py   Microsoft FARA's rubric x top-K screenshot verifier
examples/
  toy_end_to_end.py
tests/
```

`core` never imports from `adapters`. If you're wiring this tool to a new
evaluator, add a module under `adapters/`; do not add evaluator-specific
branches to `core`.

## Provenance

Extracted from an internal research project's `experiment_path_uv/`
(a check of whether "evidence collected then discarded before a verdict"
also occurs in a public screenshot-judging evaluator, alongside that
project's own audit of a text-extraction pipeline). The
`adapters/universal_verifier.py` grouping/filtering functions are
reproduced from Microsoft's `fara` repository (MIT); see that module's
docstring for exactly what is and is not verified-official there. This
package is a standalone extraction: it does not import from, and should
not be imported by, whatever project it was pulled out of, so that
neither side's changes can silently affect the other.

## License

MIT. See `LICENSE`.
