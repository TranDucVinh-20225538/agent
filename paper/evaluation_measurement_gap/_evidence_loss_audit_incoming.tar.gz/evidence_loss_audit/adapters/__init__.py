"""Evaluator-specific adapters.

Nothing in `evidence_loss_audit.core` should ever need to import from
here. An adapter's job is to turn one specific evaluator's own concepts
(rubric criteria, relevance scores, whatever its filter actually is) into
the generic inputs `core.discard`, `core.lock`, and `core.protocol` need
(index lists, `Episode` objects, `ItemJudgement`s) -- and nothing more.
If you are wiring this tool to a new evaluator, write a new module here;
do not add evaluator-specific branches to `core`.
"""
