"""Adapter for Microsoft FARA's MMRubricAgent-style rubric x top-K
screenshot verifier ("Universal Verifier", UV).

This module is UV-specific by design, so the generic core
(`evidence_loss_audit.core`) never has to know what a "criterion" or a
"relevance score" is. If you are wiring this tool to a different
evaluator (an LLM judge with a different filtering step, a different
top-K rule, a non-visual evidence channel), this file -- not the core --
is the one to copy and replace.

Provenance and what is and is not "official" here
---------------------------------------------------
`group_screenshots_by_criterion` and `filter_irrelevant_screenshots`
below are reproduced from `microsoft/fara`'s
`webeval/src/webeval/rubric_agent/mm_rubric_agent.py` (MIT-licensed) --
this is UV's actual Step-3 grouping and relevance filter, copied as-is.
`DEFAULT_K = 5` is `MMRubricAgentConfig.max_images_per_criterion`'s
published default.

`RELEVANCE_PROMPT_TEMPLATE` below was used, in the project this package
was extracted from, as the project's own reconstruction of UV's
`MM_SCREENSHOT_CRITERION_RELEVANCE_PROMPT`. Treat it as "believed to
match the official prompt at the time it was copied" rather than as a
verified-in-this-package fact -- pin your own upstream commit and
sha256 if the exact wording matters to you (Universal Verifier is a
moving target upstream), and do not assume this package keeps that pin
current.

`RUBRIC_PROMPT_TEMPLATE` below is explicitly **not** official. The real
MMRubricAgent derives its rubric through its own multi-step process
(its steps 0a/0b/0c); this is a short, self-authored substitute used
only to reconstruct a UV-shaped relevance-and-discard pipeline when you
do not have the official rubric-generation step available. If you use
it, say so in your own writeup -- do not describe results produced with
it as "the official UV rubric."

Neither prompt calling code (an actual HTTP client, image encoding,
retries, spend caps) is included here on purpose: that is
deployment-specific plumbing, not evaluator logic, and does not belong
in a reusable audit package. `uv_discard()` below takes already-computed
relevance scores; wire your own model call to produce them.
"""

from __future__ import annotations

from string import Template
from typing import Dict, List

from ..core.discard import discard_indices

DEFAULT_K = 5  # MMRubricAgentConfig.max_images_per_criterion default


def group_screenshots_by_criterion(
    relevance_scores: Dict[int, Dict], num_criteria: int, max_k: int = DEFAULT_K
) -> Dict[int, List[int]]:
    """UV's own Step-3 grouping: for each criterion, keep the top `max_k`
    screenshots by relevance score (ties broken toward the earlier
    screenshot index). Reproduced as-is from `mm_rubric_agent.py`.
    """
    grouped: Dict[int, List[int]] = {c: [] for c in range(num_criteria)}
    for screenshot_idx, scores_dict in relevance_scores.items():
        for key, score in scores_dict.items():
            if key == "screenshot_idx":
                continue
            grouped[int(key)].append((int(screenshot_idx), int(score)))
    for c in grouped:
        grouped[c].sort(key=lambda x: (x[1], x[0]), reverse=True)
        grouped[c] = [s for s, _ in grouped[c][:max_k]]
    return grouped


def filter_irrelevant_screenshots(
    grouped: Dict[int, List[int]], relevance_scores: Dict[int, Dict]
) -> Dict[int, List[int]]:
    """UV's own relevance filter, applied after top-K grouping: within a
    criterion's kept list, drop screenshots scored well below that
    criterion's own strongest kept screenshot. Reproduced as-is from
    `mm_rubric_agent.py`.
    """
    filtered: Dict[int, List[int]] = {}
    for c_idx, s_indices in grouped.items():
        scored = [(s, int(relevance_scores.get(s, {}).get(c_idx, 0))) for s in s_indices]
        high_scores = [s for _, s in scored if s >= 6]
        if not high_scores:
            filtered[c_idx] = s_indices
            continue
        min_high = min(high_scores)
        kept = [s for s, score in scored if not (score < 5 and (min_high - score) > 2)]
        filtered[c_idx] = kept if kept else s_indices
    return filtered


def uv_discard(
    n_frames: int, relevance_scores: Dict[int, Dict], num_criteria: int, max_k: int = DEFAULT_K
) -> list[int]:
    """End to end: relevance scores -> UV's own grouping+filtering ->
    discard set (via the generic core). This is the function most callers
    want; `group_screenshots_by_criterion`/`filter_irrelevant_screenshots`
    are exposed separately mainly so you can inspect the intermediate
    per-criterion keep-lists (e.g. for a `core.lock.Episode.discard_indices`
    you also want to sanity-check by hand).
    """
    grouped = filter_irrelevant_screenshots(
        group_screenshots_by_criterion(relevance_scores, num_criteria, max_k),
        relevance_scores,
    )
    return discard_indices(n_frames, grouped)


RELEVANCE_PROMPT_TEMPLATE = Template(
    """Task: $task_definition$init_url_context

You are analyzing a screenshot from an agent's trajectory to determine which rubric criteria this screenshot is most relevant to.

**Rubric Criteria:**
$rubric_criteria

**Your Task:**
For EACH criterion listed above, assign a relevance score from 0-10 indicating how much this screenshot helps evaluate that specific criterion.

**Scoring Guidelines:**
- **10**: Screenshot directly shows critical evidence for this criterion (e.g., shows the exact item being searched, cart contents, confirmation page)
- **7-9**: Screenshot shows important contextual information for this criterion (e.g., search results, filters applied, navigation state)
- **4-6**: Screenshot shows somewhat relevant information for this criterion (e.g., related page, partial information)
- **1-3**: Screenshot shows minimal relevance to this criterion (e.g., wrong page, unrelated content)
- **0**: Screenshot is completely irrelevant to this criterion

**Important:**
- A screenshot can be highly relevant to multiple criteria
- Focus on what is VISIBLE in the screenshot, not what the agent claimed to do
- Consider whether the screenshot confirms or contradicts criterion requirements

Please output a JSON object with scores for ALL criteria:

{
 "criterion_0": <score_0_to_10>,
 "criterion_1": <score_0_to_10>,
 ...
 "criterion_N": <score_0_to_10>
}

DO NOT OUTPUT ANYTHING OTHER THAN JSON.
"""
)
"""Believed to match UV's own `MM_SCREENSHOT_CRITERION_RELEVANCE_PROMPT`
at the time this package was extracted (see module docstring) -- verify
against your own upstream pin before treating the wording as canonical."""

RUBRIC_PROMPT_TEMPLATE = Template(
    """Task: $task
Start URL: $init_url

Extract 4-8 evaluation criteria EXPLICITLY stated in the task. No inferred extras.
JSON only:
{"items": [{"criterion": "...", "description": "..."}, ...]}
"""
)
"""NOT official -- see module docstring. A short, self-authored
substitute for MMRubricAgent's own multi-step rubric derivation."""
