"""evidence-loss-audit: audit an observation-then-filter evaluator for
evidence that was collected and then discarded before a verdict.

This package does not decide, on its own, that evidence was "lost." It
gives you:

  * a generic discard-set computation (`core.discard`) for any evaluator
    that keeps only the top observations per criterion and discards the
    rest;
  * a four-link chain of claims -- opportunity, discard,
    decisive-in-isolation, irrecoverable (`core.chain`) -- that keeps
    those claims from collapsing into one number;
  * a pre-registration ("lock") generator so your sampling rule is frozen
    before you see the rates it produces (`core.lock`);
  * a two-stage blinded human-annotation protocol builder, including the
    kept-set redundancy check with anti-inference foils (`core.protocol`);
  * inter-rater reliability utilities (`core.irr`).

Only the last link of the chain (IRRECOVERABLE) is licensed to support the
claim "this evidence was collected and then discarded, and no equivalent
evidence survived elsewhere." Every earlier link is a weaker, machine-only
condition; see `core/chain.py`'s module docstring before reporting any of
them as if they were the last one.

See `evidence_loss_audit.adapters` for evaluator-specific wiring (e.g.
Microsoft FARA's rubric x top-K screenshot verifier). The core package
itself has no knowledge of screenshots, rubrics, or any specific evaluator.
"""

from .core.discard import discard_indices, discard_set
from .core.chain import ItemJudgement, LossClass, ChainSummary, classify, summarize
from .core.lock import Episode, SampleRule, SampleDraw, Stage1Item, draw_sample
from .core.protocol import (
    Stage1AnnotationItem,
    Stage2AnnotationItem,
    DecisiveTarget,
    build_stage1_sheet,
    build_stage2_sheet,
)
from .core.irr import majority_label, cohen_kappa, fleiss_kappa

__version__ = "0.1.0"

__all__ = [
    "discard_indices",
    "discard_set",
    "ItemJudgement",
    "LossClass",
    "ChainSummary",
    "classify",
    "summarize",
    "Episode",
    "SampleRule",
    "SampleDraw",
    "Stage1Item",
    "draw_sample",
    "Stage1AnnotationItem",
    "Stage2AnnotationItem",
    "DecisiveTarget",
    "build_stage1_sheet",
    "build_stage2_sheet",
    "majority_label",
    "cohen_kappa",
    "fleiss_kappa",
]
