"""Generic post-filter discard-set computation.

Many evaluators score an episode's evidence (e.g. a rubric of criteria) by
keeping only the top-K most relevant observations (e.g. screenshots) *per
criterion*, then implicitly discarding everything that did not make the
cut for *any* criterion. This module computes that discard set generically,
given only the per-criterion keep-lists -- it has no knowledge of what an
"observation" or a "criterion" actually is, and no knowledge of scores,
thresholds, or K. Those choices belong in an adapter (see
`evidence_loss_audit.adapters`); this module is just the union/complement
arithmetic, so it can be reused unchanged for any per-criterion top-K (or
any other multi-list keep) filter.

This makes no claim about whether a discarded observation actually
mattered. See `core.chain` for the classification that keeps that claim
separate from this purely mechanical step.
"""

from __future__ import annotations

from typing import Hashable, Iterable, Mapping, Sequence, TypeVar

Obs = TypeVar("Obs", bound=Hashable)


def discard_set(
    all_observations: Sequence[Obs], keep_lists: Mapping[object, Sequence[Obs]]
) -> list[Obs]:
    """Observations kept by none of the per-criterion keep lists.

    `keep_lists` maps an arbitrary criterion id to the list of observations
    kept for that criterion (already truncated to top-K, or otherwise
    filtered, by the caller -- this function does no truncation itself).
    An observation survives (is NOT discarded) if it appears in *at least
    one* criterion's keep list: this is a union, not an intersection,
    matching Microsoft FARA's MMRubricAgent Step-3 grouping
    (github.com/microsoft/fara, mm_rubric_agent.py) and the equivalent
    step in any rubric x top-K judge.

    Order of `all_observations` is preserved in the result.
    """
    keep: set[Obs] = set()
    for lst in keep_lists.values():
        keep.update(lst)
    return [o for o in all_observations if o not in keep]


def discard_indices(
    n_observations: int, keep_index_lists: Mapping[object, Iterable[int]]
) -> list[int]:
    """Index-based convenience wrapper: observations are positions 0..n-1.

    Drop-in equivalent of the original per-project `discard_set(n_frames,
    grouped)` helper this package was extracted from -- kept as a thin
    wrapper around the generic `discard_set` above so existing call sites
    do not need to construct a `range()` themselves.
    """
    return discard_set(list(range(n_observations)), keep_index_lists)
