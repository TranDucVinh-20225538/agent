"""Core, evaluator-agnostic pieces. Nothing in this subpackage should ever
need to import anything from `evidence_loss_audit.adapters` -- if a change
here starts requiring that, it belongs in an adapter instead.
"""
