"""The four-link evidential-loss chain.

    opportunity  ->  discard  ->  decisive-in-isolation  ->  irrecoverable

Each link narrows the claim you are entitled to make. Skipping a link and
reporting only the first ("N observations could in principle have been
affected by the filter") as if it were the last ("N observations of
decisive evidence were unrecoverably lost") is the single most common
overclaim this package exists to prevent.

  * **opportunity** -- a population-level, mechanical condition under
    which the filter *could* discard something (e.g. an episode has more
    observations than the filter's cap K). This alone says nothing about
    whether anything was actually discarded, let alone lost.
  * **discard** -- the filter's own mechanical output (see `core.discard`):
    a specific observation was not kept by any criterion's keep-list.
    Still says nothing about whether that observation carried evidence
    anyone needed.
  * **decisive-in-isolation** (Stage 1, human, blind to keep/discard and
    blind to every other observation in the episode) -- "if this were the
    only observation shown, would it by itself be necessary to reach the
    correct verdict?" A discarded-and-decisive-in-isolation observation is
    still not proof of loss: the same evidence might survive elsewhere in
    the kept set.
  * **irrecoverable** (Stage 2, human, blind to which gallery item was the
    "real" kept set vs. a same-episode foil) -- decisive-in-isolation, and
    no kept observation in the same episode carries equivalent evidence.
    **Only this last class is licensed to support an "evidence was
    collected and then lost" claim.** A decisive-but-discarded observation
    whose evidence also survives in a kept observation is REDUNDANT loss,
    not this analogue -- report it separately, never merged into the
    headline rate.

Every step here is deliberately inert about what "evidence," "decisive,"
or "equivalent" mean for your evaluator -- you supply those judgments
(typically via `core.protocol`'s blinded sheets and your own annotators);
this module only enforces that the judgments compose in the right order
and reports every intermediate count, so a shortcut is visible even if
someone takes one anyway.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Sequence


class LossClass(str, Enum):
    NOT_DECISIVE = "NOT_DECISIVE"  # stage 1: not decisive in isolation -> not a loss question at all
    HOLD = "HOLD"  # UNCLEAR at stage 1 or stage 2 -> excluded from the primary rate, report the hold count separately
    KEPT = "KEPT"  # decisive, but the filter did not discard it -> not a loss question
    REDUNDANT = "REDUNDANT"  # decisive, discarded, but an equivalent kept observation exists elsewhere in the episode
    IRRECOVERABLE = "IRRECOVERABLE"  # decisive, discarded, no equivalent kept observation -- the only class licensed as "evidence was lost"


@dataclass(frozen=True)
class ItemJudgement:
    """One sampled (episode, observation) pair with its human labels.

    `stage1_decisive`: True/False/None (None = UNCLEAR at stage 1).
    `stage2_equivalent`: only meaningful when `discarded and stage1_decisive
    is True`; True = an equivalent kept observation exists (REDUNDANT),
    False = none does (IRRECOVERABLE), None = not asked yet or UNCLEAR.
    """

    item_id: str
    discarded: bool
    stage1_decisive: bool | None
    stage2_equivalent: bool | None = None


def classify(item: ItemJudgement) -> LossClass:
    if item.stage1_decisive is None:
        return LossClass.HOLD
    if not item.stage1_decisive:
        return LossClass.NOT_DECISIVE
    if not item.discarded:
        return LossClass.KEPT
    if item.stage2_equivalent is None:
        return LossClass.HOLD
    return LossClass.REDUNDANT if item.stage2_equivalent else LossClass.IRRECOVERABLE


@dataclass
class ChainSummary:
    """Counts and rates for one sampled population of ItemJudgements.

    `n_opportunity` and `n_discard_total` are population-level counts you
    supply from outside this sample (e.g. from `core.discard` run over the
    full corpus) -- they contextualize the sample but are not themselves
    part of any rate computed here. Pass `None` for either if you don't
    have (or don't want to report) that population count.
    """

    n_opportunity: int | None
    n_discard_total: int | None
    n_discard_sampled: int
    n_hold_stage1: int
    n_decisive_discard: int  # discarded AND decisive-in-isolation: the stage-2 denominator population
    n_hold_stage2: int
    n_redundant: int
    n_irrecoverable: int

    @property
    def u_iso(self) -> float | None:
        """P(decisive-in-isolation | discarded), stage-1 HOLDs excluded from
        the denominator. Secondary. This is NOT itself an evidence-loss rate
        -- an observation can be decisive in isolation and still have its
        evidence survive elsewhere in the kept set."""
        den = self.n_discard_sampled - self.n_hold_stage1
        return self.n_decisive_discard / den if den > 0 else None

    @property
    def u_red(self) -> float | None:
        """P(REDUNDANT | decisive-in-isolation and discarded), stage-2
        HOLDs excluded. Secondary: this is evidence that was discarded but
        did NOT get lost."""
        den = self.n_decisive_discard - self.n_hold_stage2
        return self.n_redundant / den if den > 0 else None

    @property
    def u_irr(self) -> float | None:
        """P(IRRECOVERABLE | decisive-in-isolation and discarded), stage-2
        HOLDs excluded. **Primary estimand** -- the only rate this package
        licenses as an "evidence was collected, discarded, and did not
        survive elsewhere" claim. Do not headline `u_iso` in its place."""
        den = self.n_decisive_discard - self.n_hold_stage2
        return self.n_irrecoverable / den if den > 0 else None


def summarize(
    items: Sequence[ItemJudgement],
    *,
    n_opportunity: int | None = None,
    n_discard_total: int | None = None,
) -> ChainSummary:
    """Fold a list of per-item judgements into a `ChainSummary`.

    Only items with `discarded=True` contribute to `u_iso`/`u_red`/`u_irr`;
    non-discarded (`KEPT`) items you included as stage-2 foils should still
    be passed in (they simply do not enter these denominators), so that a
    foil rate can be audited separately if you want one.
    """
    discarded = [i for i in items if i.discarded]
    n_hold_s1 = sum(1 for i in discarded if i.stage1_decisive is None)
    decisive_discard = [i for i in discarded if i.stage1_decisive]
    n_hold_s2 = sum(1 for i in decisive_discard if i.stage2_equivalent is None)
    n_red = sum(1 for i in decisive_discard if i.stage2_equivalent is True)
    n_irr = sum(1 for i in decisive_discard if i.stage2_equivalent is False)
    return ChainSummary(
        n_opportunity=n_opportunity,
        n_discard_total=n_discard_total,
        n_discard_sampled=len(discarded),
        n_hold_stage1=n_hold_s1,
        n_decisive_discard=len(decisive_discard),
        n_hold_stage2=n_hold_s2,
        n_redundant=n_red,
        n_irrecoverable=n_irr,
    )
