"""Pre-registration ("lock") generator for the sampling rule used to pick
which episodes, and which observations within them, go in front of human
annotators.

The whole point of a *lock* file is that it is written and frozen BEFORE
you know how many discard events your population actually has, so the
rule cannot be tuned after you have seen the rates it would produce. This
module gives you:

  * `SampleRule` -- the frozen rule, as plain data, so it can be rendered
    to a lock document and committed before a single episode is loaded.
  * `draw_sample()` -- a pure, seeded function that applies a `SampleRule`
    to a population and returns exactly which episodes and observations
    were selected.
  * `render_lock_markdown()` / `render_draw_record_markdown()` -- render
    the rule (before data) and the draw (after data) to Markdown, in that
    order, so a reviewer can see the rule was not written to fit the data.

Reproducibility warning
------------------------
A `random.Random(seed)` draw over data loaded from JSON/JSONL is only
reproducible if the population is placed in a **canonical order** first.
Iteration order of a JSONL file depends on how it was written, which can
silently change between runs (e.g. if the population is regenerated with
a different task-completion order). `draw_sample()` always sorts the
population by `Episode.key` before doing anything else; if two episodes
can legitimately share a key in your domain, pick a key that is unique,
or the draw is not guaranteed reproducible. This exact bug -- an
unsorted population silently breaking a locked seed's reproducibility --
was found and fixed in the project this package was extracted from
before any human annotation ran; do not reintroduce it by shuffling or
otherwise reordering `population` before calling `draw_sample`.
"""

from __future__ import annotations

import random
import statistics
from dataclasses import dataclass, field
from typing import Callable, Sequence


@dataclass(frozen=True)
class Episode:
    """One unit that can contain zero or more discarded observations.

    `discard_indices` are positions (0..n_items-1) the filter discarded,
    e.g. the output of `core.discard.discard_indices` for this episode.
    An episode with `discard_indices == ()` is a candidate *control*
    (nothing to test recoverability on), not a candidate *event*.
    """

    key: str
    n_items: int
    discard_indices: tuple[int, ...] = ()

    @property
    def n_discard(self) -> int:
        return len(self.discard_indices)

    @property
    def keep_indices(self) -> tuple[int, ...]:
        d = set(self.discard_indices)
        return tuple(i for i in range(self.n_items) if i not in d)


@dataclass(frozen=True)
class SampleRule:
    """A sampling rule, frozen and rendered to a lock document BEFORE the
    population is loaded. Every field has a docstring-level justification
    because every field is something a reviewer (or a future you) may ask
    "why this number, and was it picked before or after seeing the data?"
    about.
    """

    seed: int
    census_cutoff: int = 40
    """If the number of event episodes (n_discard >= 1) is <= this, take
    ALL of them (a census) rather than sampling."""
    n_controls: int = 20
    """Target number of control episodes (n_discard == 0) to draw."""
    max_keep_frames_per_event: int | None = None
    """Cap on sampled *kept* observations per event episode, for Stage 1's
    matched-keep comparison set. None = min(n_discard, n_keep) (the same
    count as the discarded observations, so Stage 1 is not skewed toward
    either class by volume)."""
    max_frames_per_control: int = 10
    """Cap on sampled observations per control episode for Stage 1."""
    pilot_size: int = 6
    """Number of event episodes to run first, across all annotators, to
    catch codebook ambiguity before spending the full sample. This is a
    SUBSET of the locked sample (not a separate draw) -- it counts toward
    every downstream rate; do not drop the pilot episodes afterward."""
    control_requires_opportunity: bool = True
    """If True, a zero-discard episode only qualifies as a control when it
    also had "opportunity" (see `opportunity` callback to `draw_sample`)
    -- i.e. it is a genuine case of "could have discarded something, and
    didn't," not just a small episode nothing could ever be discarded
    from."""


@dataclass(frozen=True)
class Stage1Item:
    episode_key: str
    item_index: int
    in_discard: bool
    role: str  # "event" | "control"
    reason: str  # "all_discard" | "matched_keep" | "control_item"


@dataclass
class SampleDraw:
    event: list[Episode]
    control: list[Episode]
    pilot_keys: list[str]
    stage1_items: list[Stage1Item]


def _pick_controls(candidates: Sequence[Episode], event: Sequence[Episode], n_ctrl: int) -> list[Episode]:
    """Nearest |n_items - median(event n_items)|; ties broken by `key`
    (stable, no extra RNG draw at the tie boundary -- matching the locked
    rule this package was extracted from, which found and fixed a
    doc/code mismatch here: it is tie-break-by-key, not a second RNG
    stream, and the two must not silently drift apart again)."""
    if n_ctrl <= 0 or not candidates:
        return []
    med = statistics.median(e.n_items for e in event) if event else 0
    ranked = sorted(candidates, key=lambda e: (abs(e.n_items - med), e.key))
    return sorted(ranked[:n_ctrl], key=lambda e: e.key)


def draw_sample(
    population: Sequence[Episode],
    rule: SampleRule,
    opportunity: Callable[[Episode], bool] | None = None,
) -> SampleDraw:
    """Apply `rule` to `population`. Pure and deterministic given the same
    `population` contents (order-independent -- see module docstring) and
    the same `rule.seed`.

    `opportunity(episode) -> bool`: only consulted for zero-discard
    episodes, and only when `rule.control_requires_opportunity` is True.
    Typically `lambda e: e.n_items > K` for a top-K filter. If you omit
    it, every zero-discard episode is control-eligible regardless of
    whether the filter had anything to discard from.
    """
    pop = sorted(population, key=lambda e: e.key)
    event_pool = sorted((e for e in pop if e.n_discard >= 1), key=lambda e: e.key)

    def is_control(e: Episode) -> bool:
        if e.n_discard != 0:
            return False
        if rule.control_requires_opportunity and opportunity is not None:
            return opportunity(e)
        return True

    control_pool = sorted((e for e in pop if is_control(e)), key=lambda e: e.key)

    rng = random.Random(rule.seed)
    if len(event_pool) <= rule.census_cutoff:
        event = list(event_pool)
    else:
        event = sorted(rng.sample(event_pool, rule.census_cutoff), key=lambda e: e.key)

    n_ctrl = min(rule.n_controls, len(control_pool))
    control = _pick_controls(control_pool, event, n_ctrl)

    pilot_keys = [e.key for e in event[: rule.pilot_size]]

    stage1: list[Stage1Item] = []
    for e in event:
        for i in sorted(e.discard_indices):
            stage1.append(Stage1Item(e.key, i, True, "event", "all_discard"))
        keep = list(e.keep_indices)
        rng.shuffle(keep)
        n_take = e.n_discard if rule.max_keep_frames_per_event is None else min(rule.max_keep_frames_per_event, e.n_discard)
        for i in sorted(keep[:n_take]):
            stage1.append(Stage1Item(e.key, i, False, "event", "matched_keep"))
    for e in control:
        pool = list(range(e.n_items))
        rng.shuffle(pool)
        for i in sorted(pool[: rule.max_frames_per_control]):
            stage1.append(Stage1Item(e.key, i, False, "control", "control_item"))

    return SampleDraw(event=event, control=control, pilot_keys=pilot_keys, stage1_items=stage1)


def render_lock_markdown(rule: SampleRule, *, title: str, universe_note: str, estimand_note: str = "") -> str:
    """Render `rule` to a Markdown lock document, to be committed BEFORE
    the population is loaded. Contains the rule only -- no drawn numbers
    -- so a reviewer can see the timing (rule first, data second) from
    the commit history alone.
    """
    lines = [
        f"# {title} -- sampling lock",
        "",
        f"**Status:** LOCKED. Seed `{rule.seed}`. Written before the population is loaded.",
        "",
        f"## Universe",
        "",
        universe_note,
        "",
        "## Rule",
        "",
        f"- Census cutoff: if the number of event units (>=1 discarded observation) is "
        f"<= {rule.census_cutoff}, take all of them; otherwise `Random({rule.seed}).sample(E, {rule.census_cutoff})`.",
        f"- Controls: up to {rule.n_controls}, nearest event-median item count, ties broken by "
        f"stable key order (no extra RNG draw at the tie boundary).",
        f"- Event Stage-1 keep sample: all discarded observations, plus "
        + (
            f"up to {rule.max_keep_frames_per_event}"
            if rule.max_keep_frames_per_event is not None
            else "min(n_discard, n_keep)"
        )
        + " kept observations, drawn without replacement.",
        f"- Control Stage-1 sample: up to {rule.max_frames_per_control} observations per control unit.",
        f"- Pilot: the first {rule.pilot_size} event units by key, after the draw above. This is a "
        f"SUBSET of the locked sample, not a separate draw -- it counts in every downstream rate.",
        f"- Control eligibility requires opportunity: {rule.control_requires_opportunity}.",
        "",
        "## Reproducibility",
        "",
        "Sort the population by key before building the event/control pools or consuming the "
        "seeded RNG. JSONL/dict write order must not change the sample.",
        "",
    ]
    if estimand_note:
        lines += ["## Estimands", "", estimand_note, ""]
    lines += [
        "## Do not",
        "",
        "- Retune this rule after seeing discard rates.",
        "- Add or drop units to chase a target rate.",
        "- Add a second RNG stream at the control tie-break (stable key order only).",
        "- Skip the pilot, or drop pilot units from the final counts.",
        "",
    ]
    return "\n".join(lines)


def render_draw_record_markdown(draw: SampleDraw, rule: SampleRule) -> str:
    """Render what was actually drawn. Append this to the lock document
    (or commit it as a follow-up) only AFTER the rule above was already
    committed -- recording the draw is a check that the rule produced a
    sane sample, not a new draw."""
    n_discard_items = sum(1 for it in draw.stage1_items if it.in_discard)
    lines = [
        f"## Recorded draw (seed `{rule.seed}`)",
        "",
        f"Event units: {len(draw.event)}. Control units: {len(draw.control)}.",
        f"Pilot ({rule.pilot_size} of event, by key): {', '.join(draw.pilot_keys) or '(none)'}",
        f"Stage-1 items: {len(draw.stage1_items)}. Discard items: {n_discard_items}.",
        "",
        "This is a check, not a new draw. Do not enlarge the sample after seeing this.",
        "",
    ]
    return "\n".join(lines)
