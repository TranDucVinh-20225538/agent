"""Inter-rater reliability and majority-vote utilities.

Generic over the label set -- pass whatever categories your codebook uses
(e.g. `("DECISIVE", "NOT_DECISIVE", "UNCLEAR")`). No dependency on numpy
or pandas; these are small, auditable, pure-Python implementations you
can read end to end in under a minute.
"""

from __future__ import annotations

from collections import Counter
from typing import Sequence


def majority_label(labels: Sequence[str], hold: str | None = None, min_votes: int = 2) -> str | None:
    """Majority vote after discarding `hold` votes (e.g. "UNCLEAR").

    Returns `None` (no majority) if fewer than `min_votes` non-held labels
    remain, or if the top count is tied between two or more labels.
    """
    votes = [x for x in labels if x and x != hold]
    if len(votes) < min_votes:
        return None
    counts = Counter(votes)
    top = max(counts.values())
    winners = [k for k, c in counts.items() if c == top]
    if len(winners) != 1 or top < min_votes:
        return None
    return winners[0]


def cohen_kappa(pairs: Sequence[tuple[str, str]], labels: Sequence[str]) -> float:
    """Cohen's kappa for two raters' paired labels over `labels`."""
    n = len(pairs)
    if n == 0:
        return float("nan")
    po = sum(1 for a, b in pairs if a == b) / n
    ca = Counter(a for a, _ in pairs)
    cb = Counter(b for _, b in pairs)
    pe = sum((ca[k] / n) * (cb[k] / n) for k in labels)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def fleiss_kappa(rows: Sequence[Sequence[str]], labels: Sequence[str]) -> float:
    """Fleiss' kappa for >=2 raters. `rows`: one row per item, one label
    per rater; every row must have the same number of raters.
    """
    n = len(rows)
    if n == 0:
        return float("nan")
    k = len(rows[0])
    if any(len(r) != k for r in rows):
        raise ValueError("fleiss_kappa needs the same number of raters on every item")
    N = n * k
    mat = [[Counter(row)[lab] for lab in labels] for row in rows]
    p = [sum(col[j] for col in mat) / N for j in range(len(labels))]
    pbar = sum((sum(x * x for x in col) - k) / (k * (k - 1)) for col in mat) / n
    pe = sum(x * x for x in p)
    return (pbar - pe) / (1 - pe) if pe < 1 else 1.0
