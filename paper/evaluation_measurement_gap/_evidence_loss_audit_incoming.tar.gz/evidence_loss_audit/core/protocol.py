"""Builders for the two-stage blinded annotation protocol.

Stage 1 (isolation): show an annotator ONE observation (plus whatever
task-level context they need) and ask a single question: "if this were
the only observation you saw, would it by itself be necessary to decide
the outcome?" (DECISIVE / NOT_DECISIVE / UNCLEAR, or your own equivalent
labels). Annotators never see which observations were kept or discarded,
and never see any other observation from the same episode.

Stage 2 (kept-set equivalence): for every observation Stage 1 called
decisive, show the annotator that observation plus a gallery of OTHER
observations from the same episode (order shuffled), and ask whether ANY
gallery item carries the same decisive evidence (EQUIVALENT /
NOT_EQUIVALENT / UNCLEAR). Discarded-and-decisive items get a gallery
drawn from the observations the filter actually kept; kept-and-decisive
items get a "foil" gallery drawn from the OTHER kept items. The foils
exist so annotators cannot infer "if I'm shown a gallery at all, this one
was discarded" -- a real blinding leak, caught and fixed in the project
this package was extracted from before any Stage-2 labels were collected.
Keep the foils; do not build a Stage-2 sheet without them.

Both builders return plain dataclasses, not files -- write them to CSV,
a spreadsheet, or a labeling UI however suits your annotators. Neither
builder ever includes the lab-only `in_discard`/`kind` tag in a field an
annotator would plausibly see; double-check your own export step
preserves that if you add fields.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Mapping, Sequence

from .lock import Episode, Stage1Item


@dataclass(frozen=True)
class Stage1AnnotationItem:
    item_id: str
    episode_key: str
    item_index: int


def build_stage1_sheet(
    stage1_items: Sequence[Stage1Item], seed: int, id_prefix: str = "S1"
) -> tuple[list[Stage1AnnotationItem], list[Stage1Item]]:
    """Shuffle `stage1_items` and assign blind item ids.

    Returns `(sheet, key)`. Give annotators only `sheet` (episode key +
    observation index + whatever content you render for it -- never
    `in_discard`/`role`/`reason`). Keep `key` in your own records to join
    labels back later; it is in the same order as `sheet` (same length,
    same item_ids via position), so `zip(sheet, key)` reconstructs pairs.
    """
    rng = random.Random(seed)
    shuffled = list(stage1_items)
    rng.shuffle(shuffled)
    sheet = [
        Stage1AnnotationItem(f"{id_prefix}-{n:04d}", it.episode_key, it.item_index)
        for n, it in enumerate(shuffled, start=1)
    ]
    return sheet, shuffled


@dataclass(frozen=True)
class DecisiveTarget:
    """One Stage-1-DECISIVE observation to build a Stage-2 gallery for."""

    episode_key: str
    item_index: int
    in_discard: bool


@dataclass(frozen=True)
class Stage2AnnotationItem:
    item_id: str
    episode_key: str
    target_index: int
    gallery_indices: tuple[int, ...]
    kind: str  # "discard_vs_keep" | "keep_foil" -- LAB ONLY, do not surface to annotators


def build_stage2_sheet(
    targets: Sequence[DecisiveTarget],
    episodes_by_key: Mapping[str, Episode],
    seed: int,
    id_prefix: str = "S2",
) -> list[Stage2AnnotationItem]:
    """Build blinded Stage-2 galleries.

    For each target: if it was discarded, the gallery is every observation
    the filter kept in that episode (`discard_vs_keep`). If it was kept
    (a foil target, itself Stage-1-decisive), the gallery is every OTHER
    kept observation in that episode, excluding the target itself
    (`keep_foil`). Both kinds are shuffled together on the returned sheet,
    and each gallery's own item order is shuffled, so neither gallery
    length nor position leaks `kind` to an annotator by pattern alone --
    though gallery length differences are an inherent, unavoidable signal
    (a `keep_foil` gallery is len(keep)-1; a `discard_vs_keep` gallery is
    len(keep)); document that limitation to your annotators' supervisor
    rather than pretending it does not exist.
    """
    rng = random.Random(seed)
    rows: list[tuple[DecisiveTarget, tuple[int, ...], str]] = []
    for t in sorted(targets, key=lambda t: (t.episode_key, t.item_index)):
        ep = episodes_by_key[t.episode_key]
        keep = list(ep.keep_indices)
        if t.in_discard:
            gallery = keep[:]
            kind = "discard_vs_keep"
        else:
            gallery = [i for i in keep if i != t.item_index]
            kind = "keep_foil"
        rng.shuffle(gallery)
        rows.append((t, tuple(gallery), kind))

    rng.shuffle(rows)
    sheet = [
        Stage2AnnotationItem(f"{id_prefix}-{n:04d}", t.episode_key, t.item_index, gallery, kind)
        for n, (t, gallery, kind) in enumerate(rows, start=1)
    ]
    return sheet
