from evidence_loss_audit.core.discard import discard_indices, discard_set


def test_discard_indices_union_across_criteria():
    # 5 observations, 2 criteria; obs 0 and 3 are kept by neither criterion.
    keep_lists = {"c0": [1, 2], "c1": [2, 4]}
    assert discard_indices(5, keep_lists) == [0, 3]


def test_discard_indices_empty_keep_lists_discards_everything():
    assert discard_indices(3, {}) == [0, 1, 2]


def test_discard_indices_all_kept_by_some_criterion():
    keep_lists = {"c0": [0, 1], "c1": [1, 2]}
    assert discard_indices(3, keep_lists) == []


def test_discard_set_generic_hashable_observations():
    obs = ["a", "b", "c", "d"]
    keep_lists = {"c0": ["a"], "c1": ["c", "d"]}
    assert discard_set(obs, keep_lists) == ["b"]


def test_discard_set_preserves_order():
    obs = [3, 1, 2]
    keep_lists = {"c0": [1]}
    # order of `obs` preserved in the result, not sorted
    assert discard_set(obs, keep_lists) == [3, 2]
