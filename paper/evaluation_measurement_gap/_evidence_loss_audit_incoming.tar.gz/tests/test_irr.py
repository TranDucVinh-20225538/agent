import math

from evidence_loss_audit.core.irr import cohen_kappa, fleiss_kappa, majority_label


def test_majority_label_simple_majority():
    assert majority_label(["A", "A", "B"]) == "A"


def test_majority_label_holds_unclear():
    assert majority_label(["A", "UNCLEAR", "A"], hold="UNCLEAR") == "A"


def test_majority_label_tie_returns_none():
    assert majority_label(["A", "B"]) is None


def test_majority_label_too_few_votes_returns_none():
    assert majority_label(["A", "UNCLEAR", "UNCLEAR"], hold="UNCLEAR") is None


def test_cohen_kappa_perfect_agreement():
    pairs = [("A", "A"), ("B", "B"), ("A", "A"), ("B", "B")]
    assert cohen_kappa(pairs, ["A", "B"]) == 1.0


def test_cohen_kappa_chance_agreement_near_zero():
    # Balanced random-looking disagreement: kappa should be low, not high.
    pairs = [("A", "B"), ("B", "A"), ("A", "A"), ("B", "B")]
    k = cohen_kappa(pairs, ["A", "B"])
    assert 0.0 <= k < 0.6


def test_fleiss_kappa_perfect_agreement():
    rows = [["A", "A", "A"], ["B", "B", "B"], ["A", "A", "A"]]
    assert fleiss_kappa(rows, ["A", "B"]) == 1.0


def test_fleiss_kappa_matches_hand_worked_example():
    # Classic textbook-style small example; just check it's a sane, finite value.
    rows = [
        ["A", "A", "B"],
        ["A", "B", "B"],
        ["B", "B", "B"],
        ["A", "A", "A"],
    ]
    k = fleiss_kappa(rows, ["A", "B"])
    assert not math.isnan(k)
    assert -1.0 <= k <= 1.0


def test_fleiss_kappa_requires_equal_raters_per_item():
    rows = [["A", "B"], ["A", "B", "A"]]
    try:
        fleiss_kappa(rows, ["A", "B"])
        assert False, "expected ValueError"
    except ValueError:
        pass
