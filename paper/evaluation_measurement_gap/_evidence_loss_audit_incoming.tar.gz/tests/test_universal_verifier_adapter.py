from evidence_loss_audit.adapters.universal_verifier import (
    filter_irrelevant_screenshots,
    group_screenshots_by_criterion,
    uv_discard,
)


def test_group_screenshots_by_criterion_top_k():
    # 4 screenshots, 1 criterion, K=2 -> keep the 2 highest-scoring.
    # Sort key is (score, idx) descending on both fields, so a tied score
    # breaks toward the HIGHER index, not the lower one -- this matches
    # the upstream `mm_rubric_agent.py` sort exactly (reverse=True on the
    # whole tuple), which is worth pinning down with a test since it is
    # easy to assume it breaks the other way.
    relevance = {
        0: {"0": 3},
        1: {"0": 9},
        2: {"0": 9},
        3: {"0": 1},
    }
    grouped = group_screenshots_by_criterion(relevance, num_criteria=1, max_k=2)
    assert grouped[0] == [2, 1]  # both score 9; higher index (2) sorts first, then (1)


def test_uv_discard_end_to_end_matches_manual_union():
    # 2 criteria, K=1: criterion 0 keeps its top screenshot, criterion 1 keeps its own.
    relevance = {
        0: {"0": 2, "1": 8},
        1: {"0": 9, "1": 1},
        2: {"0": 0, "1": 0},
    }
    disc = uv_discard(n_frames=3, relevance_scores=relevance, num_criteria=2, max_k=1)
    # criterion 0 top-1 by score: screenshot 1 (score 9); criterion 1 top-1: screenshot 0 (score 8)
    # union kept = {0, 1}; discard = {2}
    assert disc == [2]


def test_filter_irrelevant_screenshots_drops_far_below_strongest():
    grouped = {0: [0, 1, 2]}
    relevance = {0: {0: 9}, 1: {0: 8}, 2: {0: 1}}
    filtered = filter_irrelevant_screenshots(grouped, relevance)
    # screenshot 2 (score 1) is < 5 and (min_high(8) - 1) > 2 -> dropped
    assert 2 not in filtered[0]
    assert set(filtered[0]) == {0, 1}
