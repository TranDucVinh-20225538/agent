from evidence_loss_audit.core.lock import Episode, Stage1Item
from evidence_loss_audit.core.protocol import (
    DecisiveTarget,
    build_stage1_sheet,
    build_stage2_sheet,
)


def test_stage1_sheet_is_blind_and_same_length():
    items = [
        Stage1Item("t1", 0, True, "event", "all_discard"),
        Stage1Item("t1", 3, False, "event", "matched_keep"),
        Stage1Item("t2", 1, False, "control", "control_item"),
    ]
    sheet, key = build_stage1_sheet(items, seed=1)
    assert len(sheet) == len(items) == len(key)
    # sheet items expose only episode_key/item_index -- no in_discard/role/reason field exists
    assert not hasattr(sheet[0], "in_discard")
    ids = [s.item_id for s in sheet]
    assert ids == sorted(ids)  # sequential S1-0001.. regardless of shuffle
    # sheet and key are position-aligned
    for s, k in zip(sheet, key):
        assert s.episode_key == k.episode_key
        assert s.item_index == k.item_index


def test_stage2_discard_gallery_is_full_keep_set():
    ep = Episode("t1", n_items=6, discard_indices=(0, 1))
    targets = [DecisiveTarget("t1", 0, in_discard=True)]
    sheet = build_stage2_sheet(targets, {"t1": ep}, seed=1)
    assert len(sheet) == 1
    row = sheet[0]
    assert row.kind == "discard_vs_keep"
    assert sorted(row.gallery_indices) == sorted(ep.keep_indices)


def test_stage2_keep_foil_excludes_target_itself():
    ep = Episode("t1", n_items=6, discard_indices=(0,))  # keep = 1,2,3,4,5
    targets = [DecisiveTarget("t1", 2, in_discard=False)]  # a kept, decisive foil target
    sheet = build_stage2_sheet(targets, {"t1": ep}, seed=1)
    row = sheet[0]
    assert row.kind == "keep_foil"
    assert row.target_index not in row.gallery_indices
    assert sorted(row.gallery_indices) == sorted(i for i in ep.keep_indices if i != 2)


def test_stage2_mixed_targets_both_kinds_present():
    ep = Episode("t1", n_items=10, discard_indices=(0, 1))
    targets = [
        DecisiveTarget("t1", 0, in_discard=True),
        DecisiveTarget("t1", 5, in_discard=False),
    ]
    sheet = build_stage2_sheet(targets, {"t1": ep}, seed=2)
    kinds = {row.kind for row in sheet}
    assert kinds == {"discard_vs_keep", "keep_foil"}


def test_stage2_deterministic_given_seed():
    ep = Episode("t1", n_items=10, discard_indices=(0, 1, 2))
    targets = [DecisiveTarget("t1", 0, in_discard=True), DecisiveTarget("t1", 1, in_discard=True)]
    a = build_stage2_sheet(targets, {"t1": ep}, seed=5)
    b = build_stage2_sheet(targets, {"t1": ep}, seed=5)
    assert [(r.item_id, r.gallery_indices) for r in a] == [(r.item_id, r.gallery_indices) for r in b]
