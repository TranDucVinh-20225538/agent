import random

from evidence_loss_audit.core.lock import Episode, SampleRule, draw_sample


def make_population():
    # 5 event episodes (>=1 discard), 3 control episodes (0 discard, opportunity=True)
    return [
        Episode("t1", n_items=10, discard_indices=(0, 5)),
        Episode("t2", n_items=8, discard_indices=(1,)),
        Episode("t3", n_items=12, discard_indices=(2, 3, 4)),
        Episode("t4", n_items=6, discard_indices=(0,)),
        Episode("t5", n_items=20, discard_indices=(19,)),
        Episode("c1", n_items=9, discard_indices=()),
        Episode("c2", n_items=15, discard_indices=()),
        Episode("c3", n_items=3, discard_indices=()),  # small, no "opportunity"
    ]


def opportunity(e: Episode) -> bool:
    return e.n_items > 5  # arbitrary K for the test


def test_census_below_cutoff_takes_all_events():
    pop = make_population()
    rule = SampleRule(seed=42, census_cutoff=40, n_controls=2)
    draw = draw_sample(pop, rule, opportunity=opportunity)
    assert {e.key for e in draw.event} == {"t1", "t2", "t3", "t4", "t5"}


def test_control_requires_opportunity_excludes_small_episode():
    pop = make_population()
    rule = SampleRule(seed=42, census_cutoff=40, n_controls=3)
    draw = draw_sample(pop, rule, opportunity=opportunity)
    # c3 has n_items=3, fails opportunity (n_items > 5) -> excluded even though n_discard==0
    assert "c3" not in {e.key for e in draw.control}
    assert set(e.key for e in draw.control) <= {"c1", "c2"}


def test_deterministic_given_same_seed():
    pop = make_population()
    rule = SampleRule(seed=123, census_cutoff=2, n_controls=1)  # forces a real sample, not a census
    draw1 = draw_sample(pop, rule, opportunity=opportunity)
    draw2 = draw_sample(pop, rule, opportunity=opportunity)
    assert [e.key for e in draw1.event] == [e.key for e in draw2.event]
    assert [it.item_index for it in draw1.stage1_items] == [it.item_index for it in draw2.stage1_items]


def test_reproducible_regardless_of_input_order():
    """The exact bug this module's docstring warns about: shuffling the
    input population must not change the draw, because draw_sample sorts
    by key before doing anything else."""
    pop = make_population()
    shuffled = pop[:]
    random.Random(999).shuffle(shuffled)
    rule = SampleRule(seed=7, census_cutoff=2, n_controls=2)
    draw_a = draw_sample(pop, rule, opportunity=opportunity)
    draw_b = draw_sample(shuffled, rule, opportunity=opportunity)
    assert [e.key for e in draw_a.event] == [e.key for e in draw_b.event]
    assert [e.key for e in draw_a.control] == [e.key for e in draw_b.control]
    assert draw_a.stage1_items == draw_b.stage1_items


def test_stage1_event_items_cover_all_discards_plus_matched_keep():
    pop = [Episode("t1", n_items=10, discard_indices=(0, 1, 2))]
    rule = SampleRule(seed=1, census_cutoff=40, n_controls=0, max_keep_frames_per_event=None)
    draw = draw_sample(pop, rule)
    event_items = [it for it in draw.stage1_items if it.role == "event"]
    discard_items = [it for it in event_items if it.in_discard]
    keep_items = [it for it in event_items if not it.in_discard]
    assert len(discard_items) == 3  # all discards included
    assert len(keep_items) == 3  # min(n_discard, n_keep) = min(3, 7) = 3
    assert len(set(it.item_index for it in event_items)) == 6  # no duplicate indices


def test_pilot_is_subset_of_event_by_key_order():
    pop = make_population()
    rule = SampleRule(seed=1, census_cutoff=40, n_controls=0, pilot_size=2)
    draw = draw_sample(pop, rule, opportunity=opportunity)
    sorted_event_keys = sorted(e.key for e in draw.event)
    assert draw.pilot_keys == sorted_event_keys[:2]
