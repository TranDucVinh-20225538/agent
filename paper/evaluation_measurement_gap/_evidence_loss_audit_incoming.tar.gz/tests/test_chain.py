from evidence_loss_audit.core.chain import ItemJudgement, LossClass, classify, summarize


def test_classify_not_decisive():
    it = ItemJudgement("i1", discarded=True, stage1_decisive=False)
    assert classify(it) is LossClass.NOT_DECISIVE


def test_classify_stage1_hold():
    it = ItemJudgement("i1", discarded=True, stage1_decisive=None)
    assert classify(it) is LossClass.HOLD


def test_classify_kept_decisive_is_not_a_loss_question():
    it = ItemJudgement("i1", discarded=False, stage1_decisive=True)
    assert classify(it) is LossClass.KEPT


def test_classify_stage2_hold():
    it = ItemJudgement("i1", discarded=True, stage1_decisive=True, stage2_equivalent=None)
    assert classify(it) is LossClass.HOLD


def test_classify_redundant():
    it = ItemJudgement("i1", discarded=True, stage1_decisive=True, stage2_equivalent=True)
    assert classify(it) is LossClass.REDUNDANT


def test_classify_irrecoverable():
    it = ItemJudgement("i1", discarded=True, stage1_decisive=True, stage2_equivalent=False)
    assert classify(it) is LossClass.IRRECOVERABLE


def test_summarize_rates_match_hand_count():
    items = [
        ItemJudgement("a", True, True, False),   # IRRECOVERABLE
        ItemJudgement("b", True, True, False),   # IRRECOVERABLE
        ItemJudgement("c", True, True, True),    # REDUNDANT
        ItemJudgement("d", True, True, None),    # stage-2 HOLD
        ItemJudgement("e", True, False, None),   # NOT_DECISIVE (not in stage-2 denominator)
        ItemJudgement("f", True, None, None),    # stage-1 HOLD
        ItemJudgement("g", False, True, None),   # KEPT foil, not discarded -> excluded from discard rates
    ]
    summary = summarize(items, n_opportunity=93, n_discard_total=903)

    assert summary.n_opportunity == 93
    assert summary.n_discard_total == 903
    assert summary.n_discard_sampled == 6  # a..f (g is not discarded)
    assert summary.n_hold_stage1 == 1  # f
    assert summary.n_decisive_discard == 4  # a, b, c, d
    assert summary.n_hold_stage2 == 1  # d
    assert summary.n_redundant == 1  # c
    assert summary.n_irrecoverable == 2  # a, b

    # u_iso denominator excludes stage-1 holds: 6 - 1 = 5; decisive-discard = 4
    assert summary.u_iso == 4 / 5
    # u_red / u_irr denominator excludes stage-2 holds: 4 - 1 = 3
    assert summary.u_red == 1 / 3
    assert summary.u_irr == 2 / 3


def test_summarize_empty_denominator_returns_none():
    # Nothing discarded at all -> u_iso's denominator (discarded minus
    # stage-1 holds) is 0, not just small; all three rates are undefined.
    items = [ItemJudgement("a", discarded=False, stage1_decisive=True)]
    summary = summarize(items)
    assert summary.u_iso is None
    assert summary.u_red is None
    assert summary.u_irr is None


def test_summarize_zero_decisive_among_discard_is_a_real_zero_not_none():
    # One discarded, non-decisive item: u_iso denominator is 1 (not a
    # hold), numerator is 0 -- a real 0.0 rate, distinct from "undefined".
    items = [ItemJudgement("a", discarded=True, stage1_decisive=False)]
    summary = summarize(items)
    assert summary.u_iso == 0.0
    assert summary.u_red is None  # no decisive-discard items -> this denominator IS empty
    assert summary.u_irr is None
